﻿namespace OrangeBricks.Web.Controllers.Property.Commands
{
    public class AcceptViewingCommand
    {
        public int PropertyId { get; set; }

        public int ViewingId { get; set; }
    }
}