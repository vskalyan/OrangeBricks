﻿namespace OrangeBricks.Web.Models
{
    public enum ViewingStatus
    {
        Pending,
        Accepted,
        Rejected
    }
}